/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.c to edit this template
 */


#include "fscMalloc.h"
#include <assert.h>
#include <sys/mman.h>
#include <stdlib.h> /* for rand() */
#include <time.h> /* for the init of rand */
#include <stddef.h> /* for size_t */

void* fscMemorySetup(memoryStructure* m, fscAllocationMethod am, size_t sizeInBytes) {
    if (FIRST_FIT_RETURN_FIRST != am) {
        fprintf(stderr, "This code only supports the FIRST_FIT_RETURN_FIRST allocation method\n");
        return 0;
    }

    /* You need to write the code here
     */
    return 0;
}


void* fscMalloc(memoryStructure* m, size_t requestedSizeInBytes) {
        /* You need to write the code here
     */
}

void fscFree(memoryStructure* m, void * returnedMemory) {
}


/* Given a node, prints the list for you. */
void printFreeList(FILE * out, fsc_free_node_t* head) {
    /* given a node, prints the list. */
    fsc_free_node_t* current = head;
    fprintf(out, "About to dump the free list:\n");
    while (0 != current) {
        fprintf(out,
                "Node address: %'u\t Node size (stored): %'u\t Node size (actual) %'u\t Node next:%'u\n",
                current,
                current->size,
                current->size + sizeof (fsc_free_node_t),
                current->next);
        current = current->next;
    }
}